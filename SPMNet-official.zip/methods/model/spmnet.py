import abc
import logging
from email.policy import strict
from timm.models.layers import DropPath, to_2tuple, trunc_normal_
import math
import numpy as np
from torch.backends import cuda
import torch
import torch.nn as nn
import torch.nn.functional as F

from .ops import ConvBNReLU, PixelNormalizer, resize_to
from .libs import GRM_num,PSAModule

LOGGER = logging.getLogger("main")
from ..backbone.dinov2.hub.backbones import dinov2_vitb14
from ..backbone.DFormerV2 import DFormerv2_B

class mask_return(nn.Module):
    @staticmethod
    def get_coef(iter_percentage=1, method="cos", milestones=(0, 1)):
        min_point, max_point = min(milestones), max(milestones)
        min_coef, max_coef = 0, 1

        ual_coef = 1.0
        if iter_percentage < min_point:
            ual_coef = min_coef
        elif iter_percentage > max_point:
            ual_coef = max_coef
        else:
            if method == "linear":
                ratio = (max_coef - min_coef) / (max_point - min_point)
                ual_coef = ratio * (iter_percentage - min_point)
            elif method == "cos":
                perc = (iter_percentage - min_point) / (max_point - min_point)
                normalized_coef = (1 - np.cos(perc * np.pi)) / 2
                ual_coef = normalized_coef * (max_coef - min_coef) + min_coef
        return ual_coef

    @abc.abstractmethod
    def body(self):
        pass

    def forward(self, data, iter_percentage=1, **kwargs):
        mask_sup,logits = self.body(data=data)

        if self.training:
            mask = data["mask"]
            prob = logits.sigmoid()
            mask_seg = mask_sup.sigmoid()
            losses = []
            loss_str = []

            sod_loss = F.binary_cross_entropy_with_logits(input=logits, target=mask, reduction="mean")
            prompt_loss = F.binary_cross_entropy_with_logits(input=mask_seg, target=mask, reduction="mean")
            losses.append(sod_loss)
            losses.append(prompt_loss)
            loss_str.append(f"bce: {sod_loss.item():.5f}")
            loss_str.append(f"prp_bce: {(prompt_loss).item():.5f}")
            ual_coef = self.get_coef(iter_percentage=iter_percentage, method="cos", milestones=(0, 1))
            ual_loss = ual_coef * (1 - (2 * prob - 1).abs().pow(2)).mean()
            losses.append(ual_loss)
            loss_str.append(f"powual_{ual_coef:.5f}: {ual_loss.item():.5f}")
            return dict(vis=dict(sal=prob), loss=sum(losses), loss_str=" ".join(loss_str))
        else:
            return logits

    def get_grouped_params(self):
        param_groups = {"pretrained": [], "fixed": [], "retrained": []}
        for name, param in self.named_parameters():
            if name.startswith("encoder.patch_embed1."):
                param.requires_grad = False
                param_groups["fixed"].append(param)
            elif name.startswith("encoder."):
                param_groups["pretrained"].append(param)
            else:
                if "clip." in name:
                    param.requires_grad = False
                    param_groups["fixed"].append(param)
                else:
                    param_groups["retrained"].append(param)
        LOGGER.info(
            f"Parameter Groups:{{"
            f"Pretrained: {len(param_groups['pretrained'])}, "
            f"Fixed: {len(param_groups['fixed'])}, "
            f"ReTrained: {len(param_groups['retrained'])}}}"
        )
        return param_groups
class SPMNet(mask_return):
    def __init__(
        self,
        pretrained=True,
        num_frames=1,
        input_norm=True,
        mid_dim=64,
        use_checkpoint=False,
    ):
        super().__init__()
        self.encoder_p = dinov2_vitb14(pretrained=True)
        self.set_backbone(pretrained=pretrained, use_checkpoint=use_checkpoint)

        self.prp_dims = 768

        self.embed_dims = [80, 160, 320, 512]

        for param in self.encoder.parameters():
            param.requires_grad = True
        for param in self.encoder_p.parameters():
            param.requires_grad = False

        self.tra_4 = ConvBNReLU(self.embed_dims[3], mid_dim, 3, 1, 1)
        self.prp_4 = ConvBNReLU(self.prp_dims, mid_dim, 3, 1, 1)
        self.FSP_4 = PSAModule(mid_dim,mid_dim)
        self.GRM_4 = GRM_num(mid_dim, 64, 6)
        self.MASK_4 = PSAModule(mid_dim, mid_dim)
        self.MASK_G_4 = GRM_num(mid_dim, 64, 6)

        self.tra_3 = ConvBNReLU(self.embed_dims[2], mid_dim, 3, 1, 1)
        self.prp_3 = ConvBNReLU(self.prp_dims, mid_dim, 3, 1, 1)
        self.FSP_3 = PSAModule(mid_dim,mid_dim)
        self.GRM_3 = GRM_num(mid_dim, 64, 6)
        self.MASK_3 = PSAModule(mid_dim, mid_dim)
        self.MASK_G_3 = GRM_num(mid_dim, 64, 6)

        self.tra_2 = ConvBNReLU(self.embed_dims[1], mid_dim, 3, 1, 1)
        self.prp_2 = ConvBNReLU(self.prp_dims, mid_dim, 3, 1, 1)
        self.FSP_2 = PSAModule(mid_dim,mid_dim)
        self.GRM_2 = GRM_num(mid_dim, 64, 6)
        self.MASK_2 = PSAModule(mid_dim, mid_dim)
        self.MASK_G_2 = GRM_num(mid_dim, 64, 6)

        self.tra_1 = ConvBNReLU(self.embed_dims[0], mid_dim, 3, 1, 1)
        self.prp_1 = ConvBNReLU(self.prp_dims, mid_dim, 3, 1, 1)
        self.FSP_1 = PSAModule(mid_dim,mid_dim)
        self.GRM_1 = GRM_num(mid_dim, 64, 6)
        self.MASK_1 = PSAModule(mid_dim, mid_dim)
        self.MASK_G_1 = GRM_num(mid_dim, 64, 6)

        self.tras = nn.Sequential(
            nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False),
            ConvBNReLU(64, mid_dim, 3, 1, 1)
        )
        self.tras_mask = nn.Sequential(
            # nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False),
            ConvBNReLU(64, mid_dim, 3, 1, 1)
        )
        self.normalizer = PixelNormalizer() if input_norm else nn.Identity()
        self.predictor = nn.Sequential(
            nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False),
            ConvBNReLU(mid_dim, 32, 3, 1, 1),
            nn.Conv2d(32, 1, 1),
        )
        self.mask=nn.Sequential(
            nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False),
            ConvBNReLU(mid_dim, 32, 3, 1, 1),
            nn.Conv2d(32, 1, 1),
        )

    def set_backbone(self, pretrained: bool, use_checkpoint: bool):
        import torch
        import os

        self.encoder = DFormerv2_B(pretrained=False)

        if pretrained:
            pretrained_path = "./weight/DFormerv2_Base_pretrained.pth"

            if os.path.exists(pretrained_path):
                try:
                    checkpoint = torch.load(pretrained_path, map_location='cpu')
                    state_dict = checkpoint.get('state_dict', checkpoint)

                    missing_keys, unexpected_keys = self.encoder.load_state_dict(state_dict, strict=False)

                    if not missing_keys and not unexpected_keys:
                        print("✅ 预训练权重加载成功")
                    else:
                        print(f"⚠️ 权重加载完成 - 缺失:{len(missing_keys)}, 多余:{len(unexpected_keys)}")

                except Exception as e:
                    print(f"❌ 权重加载失败: {e}")
            else:
                print(f"❌ 权重文件不存在: {pretrained_path}")
    def normalize_encoder(self, x,prior):
        x = self.normalizer(x)
        features = self.encoder(x,prior)
        return features
    def body(self, data):
        #stage1
        layer_indices = [3, 6, 9, 11]

        multi_layer_features = self.encoder_p.get_intermediate_layers(
            data["image_m"],
            n=layer_indices,
            reshape=True,
            return_class_token=False,
            norm=True
        )
        m4=self.prp_4(multi_layer_features[3])
        md4 = self.MASK_4(m4)
        x = self.MASK_G_4(md4)

        m3=self.prp_3(multi_layer_features[2])
        md3 = self.MASK_3(m3)
        x = self.MASK_G_3(md3 + resize_to(x, tgt_hw=md3.shape[-2:]))


        m2=self.prp_2(multi_layer_features[1])
        md2 = self.MASK_2(m2)
        x = self.MASK_G_2(md2 + resize_to(x, tgt_hw=md2.shape[-2:]))


        m1=self.prp_1(multi_layer_features[0])
        md1= self.MASK_1(m1)
        x = self.MASK_G_1(md1 + resize_to(x, tgt_hw=md1.shape[-2:]))
        x = nn.functional.interpolate(x, scale_factor=7, mode='bilinear', align_corners=False)
        x = self.tras_mask(x)
        x =self.mask(x)
        mask =x

        #stage2
        m_trans_feats = self.normalize_encoder(data["image_m"], mask)
        m = self.tra_4(m_trans_feats[3])
        md4_ = self.FSP_4(m)
        x = self.GRM_4(md4_)

        m = self.tra_3(m_trans_feats[2])
        md3_ = self.FSP_4(m)
        x = self.GRM_3(md3_ + resize_to(x, tgt_hw=md3_.shape[-2:]))

        m = self.tra_2(m_trans_feats[1])
        md2_ = self.FSP_4(m)
        x = self.GRM_2(md2_ + resize_to(x, tgt_hw=md2_.shape[-2:]))

        m = self.tra_1(m_trans_feats[0])
        md1_ = self.FSP_4(m)
        x = self.GRM_1(md1_ + resize_to(x, tgt_hw=md1_.shape[-2:]))

        x = self.tras(x)
        return mask,self.predictor(x)


