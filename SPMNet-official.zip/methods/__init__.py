from .model.spmnet import (
SPMNet,
)
